import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';
import { assessEvidence } from './ai_engine.ts';
import { modelAssist } from './ai_provider.ts';
import { bmoni, bmoniConfigured } from './bmoni.ts';

const allowedOrigins = (Deno.env.get('REACH_ALLOWED_ORIGINS') || 'http://localhost:5173,http://localhost:5500').split(',').map(v => v.trim()).filter(Boolean);
function corsFor(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowed = allowedOrigins.includes(origin) ? origin : allowedOrigins.length === 1 && allowedOrigins[0] === '*' ? '*' : '';
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-idempotency-key',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
    'Vary': 'Origin',
  };
}

const allowedCategories = new Set(['medical', 'fire', 'security', 'accident', 'other']);
const allowedPriorities = new Set(['low', 'medium', 'high', 'critical']);
const allowedChannels = new Set(['pwa', 'web', 'ussd', 'sms', 'voice', 'ivr', 'relay', 'human-relay', 'operator']);
const allowedStatuses = new Set(['reported', 'received', 'verifying', 'verified', 'assigned', 'responding', 'on_scene', 'resolved', 'closed', 'cancelled']);

function textValue(value: unknown, max = 1000): string | null {
  if (typeof value !== 'string') return null;
  const v = value.trim();
  return v ? v.slice(0, max) : null;
}

function numberValue(value: unknown, min: number, max: number): number | null {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
}

function requireUuid(value: string | null): string {
  if (!value || !/^[0-9a-f-]{36}$/i.test(value)) throw new Error('Invalid resource id');
  return value;
}

Deno.serve(async (req) => {
  const cors = corsFor(req);
  const json = (body: unknown, status = 200, headers: Record<string,string> = {}) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...cors, ...headers } });
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });

  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api/, '') || '/';
  const authHeader = req.headers.get('Authorization') ?? '';
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
    global: { headers: { Authorization: authHeader } },
  });
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  const serviceSupabase = serviceRoleKey ? createClient(Deno.env.get('SUPABASE_URL')!, serviceRoleKey) : null;
  const requireService = () => { if (!serviceSupabase) throw new Error('Server service-role configuration is missing'); return serviceSupabase; };

  if (path === '/health' && req.method === 'GET') {
    return json({ ok: true, service: 'reach-api', time: new Date().toISOString() });
  }


  if (path === '/webhooks/bmoni' && req.method === 'POST') {
    // Official BMONI contract: X-Webhook-Signature = hex(HMAC-SHA256(secretKey, rawBody))
    // X-Webhook-Id = body.id; Body: { id, eventType, payload, timestamp }
    // Legacy x-bmoni-* headers retained as fallback.
    const service = requireService();
    const rawBody = await req.text();
    if (rawBody.length > 512 * 1024) return json({ error: 'Webhook body too large' }, 413);
    const signature = req.headers.get('x-webhook-signature')
      || req.headers.get('x-bmoni-signature')
      || req.headers.get('x-signature')
      || '';
    const webhookSecret = Deno.env.get('BMONI_WEBHOOK_SECRET') || '';
    if (!webhookSecret || !signature) return json({ error: 'Webhook verification is not configured' }, 503);
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey('raw', encoder.encode(webhookSecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const rawDigest = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(rawBody)));
    const expectedHex = Array.from(rawDigest).map(b => b.toString(16).padStart(2, '0')).join('');
    const supplied = signature.replace(/^sha256=/i, '').trim().toLowerCase();
    let valid = supplied.length === expectedHex.length;
    if (valid) {
      let diff = 0;
      for (let i = 0; i < expectedHex.length; i++) diff |= supplied.charCodeAt(i) ^ expectedHex.charCodeAt(i);
      valid = diff === 0;
    }
    if (!valid) return json({ error: 'Invalid webhook signature' }, 401);
    let payload: any = {};
    try { payload = JSON.parse(rawBody); } catch { return json({ error: 'Invalid webhook JSON' }, 400); }
    const eventType = String(payload.eventType || req.headers.get('x-bmoni-event-type') || 'unknown').slice(0, 120);
    const digest = await crypto.subtle.digest('SHA-256', encoder.encode(rawBody));
    const fallbackEventId = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
    const eventId = String(
      payload.id
      || req.headers.get('x-webhook-id')
      || req.headers.get('x-bmoni-event-id')
      || req.headers.get('x-event-id')
      || fallbackEventId
    ).slice(0, 200);
    const existing = await service.from('bmoni_webhook_events').select('id,processed_at').eq('event_id', eventId).maybeSingle();
    if (existing.data?.processed_at) return json({ ok: true, duplicate: true });
    if (!existing.data) {
      const inserted = await service.from('bmoni_webhook_events').insert({ event_id: eventId, event_type: eventType, signature_verified: true, payload });
      if (inserted.error && !String(inserted.error.message || '').toLowerCase().includes('duplicate')) throw inserted.error;
    }
    const proposalId = payload?.proposalId || payload?.proposal?.id || payload?.data?.proposalId || payload?.data?.proposal?.id;
    const providerTransactionId = payload?.transactionId || payload?.transaction?.id || payload?.data?.transactionId || payload?.data?.transaction?.id;
    const statusRaw = String(payload?.status || payload?.data?.status || '').toLowerCase();
    try {
      const result = await service.rpc('process_bmoni_webhook_event', {
        p_event_id: eventId,
        p_proposal_id: proposalId ? String(proposalId) : null,
        p_provider_transaction_id: providerTransactionId ? String(providerTransactionId) : null,
        p_status: statusRaw,
        p_payload: payload,
      });
      if (result.error) throw result.error;
      return json({ ok: true, ...(result.data || {}) });
    } catch (error) {
      // Keep processed_at null so the provider can safely retry after a transient/local failure.
      return json({ error: 'Webhook processing failed; retry is required' }, 500);
    }
  }

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json({ error: 'Authentication required' }, 401);

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('id,full_name,role,institution_id,relay_enabled')
    .eq('id', user.id)
    .single();
  if (profileError || !profile) return json({ error: 'Profile not found' }, 403);

  const rateLimit = await supabase.rpc('check_reach_rate_limit', { p_bucket_key: `${user.id}:${req.method}:${path}`, p_limit: req.method === 'GET' ? 120 : 30, p_window_seconds: 60 });
  if (rateLimit.error) throw rateLimit.error;
  if (rateLimit.data === false) return json({ error: 'Rate limit exceeded. Please retry shortly.' }, 429);

  try {
    if (path === '/devices/register' && req.method === 'POST') {
      const body = await req.json();
      const deviceId = textValue(body.device_id, 160);
      const publicKey = textValue(body.public_key, 4096);
      if (!deviceId || !publicKey) return json({ error: 'device_id and public_key are required' }, 422);
      const { data, error } = await supabase.rpc('register_my_relay_device', {
        p_device_id: deviceId,
        p_public_key: publicKey,
        p_platform: textValue(body.platform, 40) ?? 'android',
        p_metadata: typeof body.metadata === 'object' && body.metadata ? body.metadata : {},
      });
      if (error) throw error;
      return json({ data }, 201);
    }

    if (path === '/me' && req.method === 'GET') return json({ data: { ...profile, email: user.email } });
    if (path === '/me' && req.method === 'PATCH') {
      const body = await req.json();
      const patch: Record<string, unknown> = {};
      if (body.full_name !== undefined) patch.full_name = textValue(body.full_name, 160) || profile.full_name;
      if (body.phone !== undefined) patch.phone = textValue(body.phone, 40);
      if (body.relay_enabled !== undefined) patch.relay_enabled = Boolean(body.relay_enabled);
      const { data, error } = await supabase.from('profiles').update(patch).eq('id', user.id).select('id,full_name,phone,role,institution_id,relay_enabled').single();
      if (error) throw error;
      return json({ data });
    }


    if (path === '/operator/provision' && req.method === 'POST') {
      const body = await req.json();
      const configuredKey = Deno.env.get('REACH_OPERATOR_PROVISION_KEY');
      if (!configuredKey || typeof body.key !== 'string' || body.key.length < 32 || body.key !== configuredKey) return json({ error: 'Invalid operator provisioning key' }, 403);
      if (profile.role !== 'citizen' || profile.institution_id) return json({ error: 'Only an unassigned account can be provisioned' }, 403);
      const { data, error } = await requireService().from('profiles').update({ role: 'operator', institution_id: null }).eq('id', user.id).eq('role', 'citizen').is('institution_id', null).select('id,role,institution_id,full_name').single();
      if (error) throw error;
      await requireService().from('audit_logs').insert({ actor_id: user.id, action: 'operator.provisioned', resource_type: 'profile', resource_id: user.id, metadata: { source: 'server_provisioning_key' } });
      return json({ data });
    }

    if (path === '/institutions' && req.method === 'POST') {
      if (profile.role !== 'citizen') return json({ error: 'Only an unassigned citizen can create an institution' }, 403);
      const body = await req.json();
      const name = textValue(body.name, 160);
      if (!name) return json({ error: 'Institution name is required' }, 422);
      const { data, error } = await supabase.rpc('create_institution_for_current_user', {
        p_name: name,
        p_category: textValue(body.category, 80) ?? 'community',
        p_city: textValue(body.city, 80),
        p_address: textValue(body.address, 240),
      });
      if (error) throw error;
      return json({ institution_id: data }, 201);
    }

    if (path === '/invites' && req.method === 'POST') {
      if (profile.role !== 'institution') return json({ error: 'Institution admin role required' }, 403);
      const body = await req.json();
      const email = textValue(body.email, 254)?.toLowerCase();
      const role = textValue(body.role, 30);
      if (!email || !email.includes('@')) return json({ error: 'Valid email is required' }, 422);
      if (role !== 'staff' && role !== 'security-desk') return json({ error: 'Invalid invite role' }, 422);
      const { data, error } = await supabase.rpc('create_staff_invite', {
        p_email: email, p_role: role, p_expires_hours: Math.min(Math.max(Number(body.expires_hours ?? 72), 1), 168),
      });
      if (error) throw error;
      return json({ code: data }, 201);
    }

    if (path === '/invites/redeem' && req.method === 'POST') {
      const body = await req.json();
      const code = textValue(body.code, 80);
      if (!code) return json({ error: 'Invite code is required' }, 422);
      const { data, error } = await supabase.rpc('redeem_staff_invite', { p_code: code });
      if (error) throw error;
      return json({ data });
    }

    if (path === '/incidents' && req.method === 'GET') {
      const limit = Math.min(Math.max(Number(url.searchParams.get('limit') ?? 50), 1), 100);
      const status = textValue(url.searchParams.get('status'), 30);
      if (status && !allowedStatuses.has(status)) return json({ error: 'Invalid status' }, 422);
      let query = supabase.from('incidents').select('id,code,institution_id,reporter_id,category,status,priority,title,description,source_channel,delivery_method,location_label,location_source,location_accuracy_m,location_context,ai_confidence,ai_fp_code,auto_pushed,via_relay,reported_at,acknowledged_at,resolved_at,closed_at,created_at,updated_at').order('reported_at', { ascending: false }).limit(limit);
      if (status) query = query.eq('status', status);
      const { data, error } = await query;
      if (error) throw error;
      return json({ data: data ?? [] });
    }

    if (path === '/incidents' && req.method === 'POST') {
      const body = await req.json();
      const idempotencyKey = textValue(req.headers.get('x-idempotency-key') ?? body.idempotency_key, 160) ?? crypto.randomUUID();
      const category = textValue(body.category, 30)?.toLowerCase() ?? 'other';
      const priority = textValue(body.priority, 20)?.toLowerCase() ?? 'high';
      const sourceChannel = textValue(body.source_channel, 30)?.toLowerCase() ?? 'pwa';
      if (!allowedCategories.has(category)) return json({ error: 'Invalid incident category' }, 422);
      if (!allowedPriorities.has(priority)) return json({ error: 'Invalid incident priority' }, 422);
      if (!allowedChannels.has(sourceChannel)) return json({ error: 'Invalid source channel' }, 422);
      const lat = numberValue(body.latitude, -90, 90);
      const lng = numberValue(body.longitude, -180, 180);
      if ((body.latitude != null || body.longitude != null) && (lat === null || lng === null)) return json({ error: 'Invalid coordinates' }, 422);
      const confidence = body.ai_confidence == null ? null : numberValue(body.ai_confidence, 0, 100);
      if (body.ai_confidence != null && confidence === null) return json({ error: 'Invalid AI confidence' }, 422);

      const payload = {
        category, priority, source_channel: sourceChannel,
        title: textValue(body.title, 160), description: textValue(body.description, 4000),
        delivery_method: textValue(body.delivery_method, 80), location_label: textValue(body.location_label, 240),
        location_source: textValue(body.location_source, 30), location_accuracy_m: numberValue(body.location_accuracy_m, 0, 100000),
        latitude: lat, longitude: lng, location_context: typeof body.location_context === 'object' && body.location_context ? body.location_context : {},
        ai_confidence: confidence, ai_fp_code: textValue(body.ai_fp_code, 80), via_relay: Boolean(body.via_relay),
      };
      const { data, error } = await supabase.rpc('create_incident_for_current_user', { p_payload: payload, p_idempotency_key: idempotencyKey });
      if (error) throw error;
      return json({ data }, 201);
    }


    const incidentGetMatch = path.match(/^\/incidents\/([^/]+)$/);
    if (incidentGetMatch && req.method === 'GET') {
      const id = requireUuid(incidentGetMatch[1]);
      const { data, error } = await supabase.from('incidents').select('id,code,institution_id,reporter_id,category,status,priority,title,description,source_channel,delivery_method,location_label,location_source,location_accuracy_m,location_context,ai_confidence,ai_fp_code,auto_pushed,via_relay,reported_at,acknowledged_at,resolved_at,closed_at,created_at,updated_at').eq('id', id).single();
      if (error) throw error;
      return json({ data });
    }

    if (path === '/contacts' && req.method === 'GET') {
      const { data, error } = await supabase.from('emergency_contacts').select('id,name,phone,relationship,notify_on_incident,created_at').eq('user_id', user.id).order('created_at');
      if (error) throw error;
      return json({ data: data ?? [] });
    }
    if (path === '/contacts' && req.method === 'POST') {
      const body = await req.json();
      const name = textValue(body.name, 120); const phone = textValue(body.phone, 40);
      if (!name || !phone) return json({ error: 'Contact name and phone are required' }, 422);
      const { data, error } = await supabase.from('emergency_contacts').insert({ user_id:user.id,name,phone,relationship:textValue(body.relationship,80),notify_on_incident:body.notify_on_incident !== false }).select('id,name,phone,relationship,notify_on_incident,created_at').single();
      if (error) throw error;
      return json({ data }, 201);
    }
    const contactMatch = path.match(/^\/contacts\/([^/]+)$/);
    if (contactMatch && req.method === 'PATCH') {
      const id = requireUuid(contactMatch[1]); const body = await req.json();
      const patch: Record<string, unknown> = {};
      if (body.name !== undefined) patch.name = textValue(body.name,120);
      if (body.phone !== undefined) patch.phone = textValue(body.phone,40);
      if (body.relationship !== undefined) patch.relationship = textValue(body.relationship,80);
      if (body.notify_on_incident !== undefined) patch.notify_on_incident = Boolean(body.notify_on_incident);
      const { data, error } = await supabase.from('emergency_contacts').update(patch).eq('id',id).eq('user_id',user.id).select('id,name,phone,relationship,notify_on_incident,created_at').single();
      if (error) throw error;
      return json({ data });
    }
    if (contactMatch && req.method === 'DELETE') {
      const id = requireUuid(contactMatch[1]);
      const { error } = await supabase.from('emergency_contacts').delete().eq('id',id).eq('user_id',user.id);
      if (error) throw error;
      return json({ ok:true });
    }

    const statusMatch = path.match(/^\/incidents\/([^/]+)\/status$/);
    if (statusMatch && req.method === 'PATCH') {
      const id = requireUuid(statusMatch[1]);
      const body = await req.json();
      const status = textValue(body.status, 30)?.toLowerCase();
      if (!status || !allowedStatuses.has(status)) return json({ error: 'Invalid incident status' }, 422);
      const verificationState = body.verification_state == null ? null : textValue(body.verification_state, 30);
      const { data, error } = await supabase.rpc('transition_incident', { p_incident_id: id, p_to: status, p_verification_state: verificationState });
      if (error) throw error;
      return json({ data });
    }

    const assignMatch = path.match(/^\/incidents\/([^/]+)\/assign$/);
    if (assignMatch && req.method === 'POST') {
      const id = requireUuid(assignMatch[1]);
      const body = await req.json();
      const responderId = requireUuid(textValue(body.responder_id, 64));
      const { data, error } = await supabase.rpc('assign_incident', { p_incident_id: id, p_responder_id: responderId });
      if (error) throw error;
      return json({ data }, 201);
    }

    if (path === '/relay/packets' && req.method === 'POST') {
      const body = await req.json();
      const packetKey = textValue(body.packet_key, 160);
      const packetHash = textValue(body.packet_hash, 256);
      const sourceDevice = textValue(body.source_device_id, 160);
      const sourceKey = textValue(body.source_public_key, 4096);
      const sourceSignature = textValue(body.source_signature, 4096);
      const sourceSignedPayload = textValue(body.source_signed_payload, 12000);
      const relayDevice = textValue(body.relay_device_id, 160);
      const relayKey = textValue(body.relay_public_key, 4096);
      const relaySignature = textValue(body.relay_signature, 4096);
      const relaySignedPayload = textValue(body.relay_signed_payload, 12000);
      if (!packetKey || !packetHash || !sourceDevice || !sourceKey || !sourceSignature || !sourceSignedPayload) return json({ error: 'Authenticated relay identity is required' }, 422);
      const hops = Number(body.hop_count ?? 0); const maxHops = Number(body.max_hops ?? 6);
      if (!Number.isInteger(hops) || !Number.isInteger(maxHops) || hops < 0 || maxHops < 1 || maxHops > 6 || hops >= maxHops) return json({ error: 'Invalid relay hop values' }, 422);
      if (relayDevice && (!relayKey || !relaySignature || !relaySignedPayload)) return json({ error: 'Relay envelope signature is incomplete' }, 422);
      const derToP1363 = (der: Uint8Array) => {
        if (der[0] !== 0x30) throw new Error('Invalid ECDSA signature');
        let i = 2; if (der[i] === 0x81) i += 1;
        if (der[i++] !== 0x02) throw new Error('Invalid ECDSA R');
        const rLen = der[i++]; const r = der.slice(i, i + rLen); i += rLen;
        if (der[i++] !== 0x02) throw new Error('Invalid ECDSA S');
        const sLen = der[i++]; const ss = der.slice(i, i + sLen);
        const out = new Uint8Array(64); out.set(r.slice(Math.max(0, r.length - 32)), 32 - Math.min(32, r.length)); out.set(ss.slice(Math.max(0, ss.length - 32)), 64 - Math.min(32, ss.length)); return out;
      };
      const canonical = (p: Record<string, unknown>, relay = false) => {
        const keys = relay ? ['v','k','e','h','m','incident_id','source_device_id','x','relay_device_id','minimal_payload'] : ['v','k','e','m','incident_id','source_device_id','x','minimal_payload'];
        const value = (v: unknown) => v && typeof v === 'object' ? JSON.stringify(v) : String(v);
        return keys.map(k => `${k}=${value(p[k])}`).join('&');
      };
      const verifyEcdsa = async (publicKeyB64: string, signatureB64: string, message: string) => {
        const keyBytes = Uint8Array.from(atob(publicKeyB64), c => c.charCodeAt(0));
        const der = Uint8Array.from(atob(signatureB64), c => c.charCodeAt(0));
        const sigBytes = derToP1363(der);
        const key = await crypto.subtle.importKey('spki', keyBytes, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
        return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, sigBytes, new TextEncoder().encode(message));
      };
      const expectedSourceSigned = canonical({ ...body, v: body.v ?? 2, k: packetKey, e: Date.parse(String(body.ttl_expires_at)), m: maxHops, incident_id: body.incident_id, source_device_id: sourceDevice, x: packetHash, minimal_payload: body.minimal_payload ?? {} });
      if (expectedSourceSigned !== sourceSignedPayload) return json({ error: 'Source signed payload does not match packet' }, 403);
      if (!(await verifyEcdsa(sourceKey, sourceSignature, sourceSignedPayload))) return json({ error: 'Invalid source packet signature' }, 403);
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(sourceSignedPayload));
      const expectedHash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
      if (expectedHash !== packetHash) return json({ error: 'Packet fingerprint mismatch' }, 403);
      if (relayDevice) {
        const expectedRelaySigned = canonical({ ...body, v: body.v ?? 2, k: packetKey, e: Date.parse(String(body.ttl_expires_at)), h: hops, m: maxHops, incident_id: body.incident_id, source_device_id: sourceDevice, x: packetHash, relay_device_id: relayDevice, minimal_payload: body.minimal_payload ?? {} }, true);
        if (expectedRelaySigned !== relaySignedPayload) return json({ error: 'Relay signed payload does not match packet' }, 403);
        if (!(await verifyEcdsa(relayKey!, relaySignature!, relaySignedPayload!))) return json({ error: 'Invalid relay signature' }, 403);
      }
      const packet = { ...body, packet_key: packetKey, packet_hash: packetHash, hop_count: hops, max_hops: maxHops, transport: textValue(body.transport, 30) ?? 'native' };
      const { data, error } = await requireService().rpc('ingest_relay_packet_service', { p_packet: packet, p_actor_id: user.id });
      if (error) throw error;
      return json({ data }, 201);
    }


    if (path === '/members' && req.method === 'GET') {
      if (!profile.institution_id) return json({ data: [] });
      const { data, error } = await supabase.rpc('list_institution_member_directory');
      if (error) throw error;
      return json({ data: data ?? [] });
    }

    if (path === '/responders' && req.method === 'GET') {
      if (!profile.institution_id && !['operator', 'super-admin'].includes(profile.role)) return json({ data: [] });
      const { data, error } = await supabase.rpc('list_responder_directory');
      if (error) throw error;
      return json({ data: data ?? [] });
    }
    if (path === '/responders' && req.method === 'POST') {
      const body = await req.json();
      const userId = requireUuid(textValue(body.user_id,64));
      const responderType = textValue(body.responder_type,40) || 'staff';
      const { data, error } = await supabase.rpc('add_responder', { p_user_id:userId, p_responder_type:responderType });
      if (error) throw error;
      return json({ data },201);
    }
    if (path === '/responders/me/status' && req.method === 'PATCH') {
      const body = await req.json();
      const status = textValue(body.status,20);
      const { data, error } = await supabase.rpc('set_my_responder_status', { p_status:status });
      if (error) throw error;
      return json({ data });
    }

    if (path === '/tasks' && req.method === 'GET') {
      const { data: responderRows, error: responderError } = await supabase.from('responders').select('id').eq('user_id', user.id);
      if (responderError) throw responderError;
      const responderIds = (responderRows ?? []).map((r: { id: string }) => r.id);
      if (!responderIds.length) return json({ data: [] });
      const { data: assignments, error: assignmentError } = await supabase.from('incident_assignments').select('id,incident_id,responder_id,status,assigned_at,accepted_at,completed_at').in('responder_id', responderIds).order('assigned_at', { ascending: false }).limit(100);
      if (assignmentError) throw assignmentError;
      const incidentIds = [...new Set((assignments ?? []).map((a: { incident_id: string }) => a.incident_id))];
      const { data: incidents, error: incidentError } = incidentIds.length ? await supabase.from('incidents').select('id,code,category,status,title,location_label,ai_confidence,ai_fp_code,source_channel,via_relay').in('id', incidentIds) : { data: [], error: null };
      if (incidentError) throw incidentError;
      const incidentMap = new Map((incidents ?? []).map((i: any) => [i.id, i]));
      return json({ data: (assignments ?? []).map((a: any) => ({ ...a, incident: incidentMap.get(a.incident_id) ?? null })) });
    }

    const taskStatusMatch = path.match(/^\/tasks\/([^/]+)\/status$/);
    if (taskStatusMatch && req.method === 'PATCH') {
      const id = requireUuid(taskStatusMatch[1]);
      const body = await req.json();
      const status = textValue(body.status, 30);
      if (!status) return json({ error: 'Task status is required' }, 422);
      const { data, error } = await supabase.rpc('transition_assignment', { p_assignment_id: id, p_status: status });
      if (error) throw error;
      return json({ data });
    }

    if (path === '/institutions' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const { data, error } = await supabase.from('institutions').select('id,name,category,city,address,timezone,created_at,updated_at').order('created_at', { ascending: false });
      if (error) throw error;
      return json({ data: data ?? [] });
    }


    if (path === '/institution/billing/bmoni' && req.method === 'GET') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const [{ data: account, error: accountError }, { data: subscription, error: subscriptionError }, { data: payments, error: paymentsError }] = await Promise.all([
        supabase.from('bmoni_institution_accounts').select('id,institution_id,bmoni_user_id,smart_wallet_id,wallet_address,currency,onboarding_status,bvn_verified,ngn_virtual_account_ready,created_at,updated_at').eq('institution_id', profile.institution_id).maybeSingle(),
        supabase.from('subscriptions').select('*').eq('institution_id', profile.institution_id).order('created_at', { ascending: false }).limit(1),
        supabase.from('payments').select('*').eq('institution_id', profile.institution_id).order('created_at', { ascending: false }).limit(20),
      ]);
      if (accountError || subscriptionError || paymentsError) throw accountError || subscriptionError || paymentsError;
      return json({
        data: {
          provider: 'BMONI Embedded',
          configured: bmoniConfigured(),
          payment_required_for: 'institution',
          end_users_pay: false,
          account: account ?? null,
          subscription: subscription?.[0] ?? null,
          payments: payments ?? [],
          configured_amount_cngn: Deno.env.get('REACH_INSTITUTION_SUBSCRIPTION_AMOUNT_CNGN') || null,
          treasury_address_configured: Boolean(Deno.env.get('REACH_BMONI_TREASURY_ADDRESS')),
        },
      });
    }

    if (path === '/institution/billing/bmoni/user' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      if (!bmoniConfigured()) return json({ error: 'BMONI is not configured on the server' }, 503);
      const body = await req.json();
      const firstName = textValue(body.first_name, 80);
      const lastName = textValue(body.last_name, 80);
      const email = textValue(body.email, 254)?.toLowerCase();
      const phoneNumber = textValue(body.phone_number, 30);
      if (!firstName || !lastName || !email || !email.includes('@') || !phoneNumber) return json({ error: 'Authorized payer first name, last name, email and phone number are required' }, 422);
      const { data: existingAccount } = await supabase.from('bmoni_institution_accounts').select('id,bmoni_user_id,onboarding_status').eq('institution_id', profile.institution_id).maybeSingle();
      if (existingAccount?.bmoni_user_id) return json({ data: existingAccount });
      let result: any;
      try { result = await bmoni.createUser({ firstName, lastName, email, phoneNumber }); }
      catch (error: any) {
        if (error?.status === 409 && error?.body) result = error.body;
        else throw error;
      }
      const bmoniUserId = result?.bmoniUserId || result?.id || result?.user?.id || result?.data?.bmoniUserId || result?.data?.id;
      if (!bmoniUserId) return json({ error: 'BMONI user already exists, but the existing user id was not returned. Resolve the account through BMONI support/admin tooling.' }, 409);
      const { data, error } = await requireService().from('bmoni_institution_accounts').upsert({
        institution_id: profile.institution_id,
        bmoni_user_id: String(bmoniUserId),
        onboarding_status: 'user_created',
        metadata: { payer_email: email, payer_phone: phoneNumber },
      }, { onConflict: 'institution_id' }).select().single();
      if (error) throw error;
      return json({ data: { id: data.id, bmoni_user_id: data.bmoni_user_id, onboarding_status: data.onboarding_status } }, 201);
    }

    if (path === '/institution/billing/bmoni/owner-proof-challenge' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const body = await req.json();
      const walletAddress = textValue(body.wallet_address, 120);
      if (!walletAddress) return json({ error: 'Wallet address is required' }, 422);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id) return json({ error: 'Create the institution BMONI payer account first' }, 409);
      const challenge = await bmoni.ownerProofChallenge(account.bmoni_user_id, { currency: 'CNGN', userOwnerAddress: walletAddress });
      return json({ data: challenge });
    }

    if (path === '/institution/billing/bmoni/wallet' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const body = await req.json();
      const walletAddress = textValue(body.wallet_address, 120);
      const challengeId = textValue(body.owner_proof_challenge_id, 200);
      const signature = textValue(body.owner_proof_signature, 300);
      if (!walletAddress || !challengeId || !signature) return json({ error: 'wallet_address, owner_proof_challenge_id and owner_proof_signature are required' }, 422);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id) return json({ error: 'Create the institution BMONI payer account first' }, 409);
      const result = await bmoni.createManagedWallet(account.bmoni_user_id, { currency: 'CNGN', userOwnerAddress: walletAddress, ownerProofChallengeId: challengeId, ownerProofSignature: signature });
      const walletId = result?.smartWalletId || result?.id || result?.smartWallet?.id;
      const returnedAddress = result?.walletAddress || result?.address || result?.smartWallet?.address || walletAddress;
      if (!walletId) return json({ error: 'BMONI did not return a smart wallet id' }, 502);
      const { data, error: updateError } = await requireService().from('bmoni_institution_accounts').update({ smart_wallet_id: String(walletId), wallet_address: returnedAddress, onboarding_status: 'wallet_created' }).eq('institution_id', profile.institution_id).select().single();
      if (updateError) throw updateError;
      return json({ data: { smart_wallet_id: data.smart_wallet_id, wallet_address: data.wallet_address, onboarding_status: data.onboarding_status } }, 201);
    }


    if (path === '/institution/billing/bmoni/kyc' && req.method === 'PATCH') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id) return json({ error: 'Create the institution BMONI payer account first' }, 409);
      const body = await req.json();
      const personalInfo = body.personalInfo;
      const addressDetails = body.addressDetails;
      if (!personalInfo || !addressDetails) return json({ error: 'personalInfo and addressDetails are required' }, 422);
      const result = await bmoni.updateKyc(account.bmoni_user_id, { personalInfo, addressDetails, ...(body.occupationCode ? { occupationCode: body.occupationCode } : {}) });
      return json({ data: result });
    }

    if (path === '/institution/billing/bmoni/start-nigeria' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const body = await req.json();
      const bvn = textValue(body.bvn, 20);
      if (!bvn || !/^\d{11}$/.test(bvn)) return json({ error: 'A valid 11-digit BVN is required' }, 422);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id,wallet_address').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id || !account.wallet_address) return json({ error: 'Create the BMONI wallet before starting Nigeria onboarding' }, 409);
      const result = await bmoni.startNigeria(account.bmoni_user_id, { bvn, ngnWalletAddress: account.wallet_address, ngnWalletIndex: Number(body.ngn_wallet_index ?? 0) });
      const { error: updateError } = await requireService().from('bmoni_institution_accounts').update({ onboarding_status: 'ngn_started', bvn_verified: true }).eq('institution_id', profile.institution_id);
      if (updateError) throw updateError;
      return json({ data: result });
    }

    if (path === '/institution/billing/bmoni/status' && req.method === 'GET') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id) return json({ error: 'BMONI payer account is not configured' }, 409);
      const result = await bmoni.onboardingStatus(account.bmoni_user_id);
      return json({ data: result });
    }

    if (path === '/institution/billing/bmoni/deposit-account' && req.method === 'GET') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id) return json({ error: 'BMONI payer account is not configured' }, 409);
      const result = await bmoni.depositAccount(account.bmoni_user_id);
      await requireService().from('bmoni_institution_accounts').update({ ngn_virtual_account_ready: true, onboarding_status: 'active' }).eq('institution_id', profile.institution_id);
      return json({ data: result });
    }

    if (path === '/institution/billing/bmoni/payment/proposal' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const body = await req.json();
      const amount = Deno.env.get('REACH_INSTITUTION_SUBSCRIPTION_AMOUNT_CNGN')?.trim() || '';
      const treasuryAddress = Deno.env.get('REACH_BMONI_TREASURY_ADDRESS')?.trim() || '';
      const idempotencyKey = textValue(req.headers.get('x-idempotency-key') || body.idempotency_key, 160);
      if (!idempotencyKey) return json({ error: 'x-idempotency-key is required for payment operations' }, 422);
      if (!amount || !/^\d+(\.\d{1,8})?$/.test(amount) || Number(amount) <= 0) return json({ error: 'A valid institutional subscription amount is required' }, 422);
      if (!treasuryAddress) return json({ error: 'REACH BMONI treasury wallet is not configured' }, 503);
      const { data: account, error } = await supabase.from('bmoni_institution_accounts').select('bmoni_user_id,smart_wallet_id').eq('institution_id', profile.institution_id).single();
      if (error || !account?.bmoni_user_id || !account.smart_wallet_id) return json({ error: 'Complete BMONI user and CNGN wallet setup before paying' }, 409);
      const service = requireService();
      const { data: existing } = await service.from('bmoni_transactions').select('*').eq('institution_id', profile.institution_id).eq('idempotency_key', idempotencyKey).maybeSingle();
      if (existing) return json({ data: existing });
      const { data: subscription } = await supabase.from('subscriptions').select('id').eq('institution_id', profile.institution_id).order('created_at', { ascending: false }).limit(1).maybeSingle();

      // Create the local financial intent BEFORE touching BMONI. The unique
      // (institution_id,idempotency_key) constraint is the concurrency guard.
      const intentInsert = await service.from('bmoni_transactions').insert({ institution_id: profile.institution_id, subscription_id: subscription?.id ?? null, bmoni_user_id: account.bmoni_user_id, smart_wallet_id: account.smart_wallet_id, idempotency_key: idempotencyKey, amount: Number(amount), currency: 'CNGN', status: 'initiated', description: textValue(body.description, 240) || 'REACH institutional subscription' }).select().single();
      if (intentInsert.error) {
        const { data: retryExisting } = await service.from('bmoni_transactions').select('*').eq('institution_id', profile.institution_id).eq('idempotency_key', idempotencyKey).maybeSingle();
        if (retryExisting) return json({ data: retryExisting });
        throw intentInsert.error;
      }
      const paymentInsert = await service.from('payments').insert({ institution_id: profile.institution_id, subscription_id: subscription?.id ?? null, amount: Number(amount), currency: 'CNGN', status: 'pending', provider: 'BMONI Embedded' }).select().single();
      if (paymentInsert.error) {
        await service.from('bmoni_transactions').update({ status: 'failed', failure_reason: String(paymentInsert.error.message || 'Unable to create payment record').slice(0,500) }).eq('id', intentInsert.data.id);
        throw paymentInsert.error;
      }
      const attachPayment = await service.from('bmoni_transactions').update({ payment_id: paymentInsert.data.id }).eq('id', intentInsert.data.id);
      if (attachPayment.error) throw attachPayment.error;

      try {
        const proposal = await bmoni.createProposal(account.bmoni_user_id, account.smart_wallet_id, { proposal: { type: 'TRANSFER', toAddress: treasuryAddress, amount, currency: 'CNGN', description: textValue(body.description, 240) || 'REACH institutional subscription' } });
        const proposalId = proposal?.proposalId || proposal?.id || proposal?.proposal?.id;
        if (!proposalId) throw new Error('BMONI did not return a proposal id');
        await bmoni.approveProposal(account.bmoni_user_id, String(proposalId));
        const signPayload = await bmoni.proposalSignPayload(account.bmoni_user_id, String(proposalId));
        const update = await service.from('bmoni_transactions').update({ proposal_id: String(proposalId), status: 'pending', sign_payload: signPayload?.hashToSign || signPayload?.payload || null, raw_response: { proposal, signPayload } }).eq('id', intentInsert.data.id).select().single();
        if (update.error) throw update.error;
        await service.from('payments').update({ provider_reference: String(proposalId) }).eq('id', paymentInsert.data.id);
        return json({ data: { transaction: update.data, proposal_id: String(proposalId), sign_payload: signPayload, signing: 'signTransactionHash', note: 'The raw 32-byte hash must be signed on the institution device using the BMONI Embedded SDK. Do not use EIP-191 for this step.' } }, 201);
      } catch (providerError) {
        await service.from('bmoni_transactions').update({ status: 'failed', failure_reason: String(providerError instanceof Error ? providerError.message : providerError).slice(0,500) }).eq('id', intentInsert.data.id);
        await service.from('payments').update({ status: 'failed' }).eq('id', paymentInsert.data.id);
        throw providerError;
      }
    }

    if (path === '/institution/billing/bmoni/payment/sign' && req.method === 'POST') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const body = await req.json();
      const proposalId = textValue(body.proposal_id, 200);
      const signature = textValue(body.signature, 300);
      if (!proposalId || !signature) return json({ error: 'proposal_id and signature are required' }, 422);
      if (!/^0x[0-9a-fA-F]{130}$/.test(signature)) return json({ error: 'Signature must be a 65-byte 0x-prefixed hexadecimal signature from the BMONI SDK' }, 422);
      const { data: tx, error } = await supabase.from('bmoni_transactions').select('*').eq('institution_id', profile.institution_id).eq('proposal_id', proposalId).single();
      if (error || !tx) return json({ error: 'BMONI payment proposal not found' }, 404);
      const result = await bmoni.signProposal(tx.bmoni_user_id, proposalId, signature);
      await requireService().from('bmoni_transactions').update({ status: 'pending', raw_response: { ...tx.raw_response, signResult: result } }).eq('id', tx.id);
      return json({ data: result });
    }

    const txMatch = path.match(/^\/institution\/billing\/bmoni\/payment\/([^/]+)$/);
    if (txMatch && req.method === 'GET') {
      if (profile.role !== 'institution' || !profile.institution_id) return json({ error: 'Institution administrator role required' }, 403);
      const id = requireUuid(txMatch[1]);
      const { data, error } = await supabase.from('bmoni_transactions').select('id,institution_id,subscription_id,proposal_id,bmoni_transaction_id,amount,currency,status,description,failure_reason,created_at,updated_at').eq('institution_id', profile.institution_id).eq('id', id).single();
      if (error || !data) return json({ error: 'Payment transaction not found' }, 404);
      return json({ data });
    }

    if (path === '/institution/summary' && req.method === 'GET') {
      if (!profile.institution_id) return json({ error: 'Institution is not configured' }, 409);
      const institutionId = profile.institution_id;
      const [{ data: institution, error: institutionError }, { data: members, error: membersError }, { data: subscription, error: subscriptionError }, { data: payments, error: paymentsError }] = await Promise.all([
        supabase.from('institutions').select('*').eq('id', institutionId).single(),
        supabase.from('institution_members').select('user_id,membership_role,status').eq('institution_id', institutionId),
        supabase.from('subscriptions').select('*').eq('institution_id', institutionId).order('created_at', { ascending: false }).limit(1),
        supabase.from('payments').select('*').eq('institution_id', institutionId).order('created_at', { ascending: false }).limit(20),
      ]);
      if (institutionError) throw institutionError;
      if (membersError || subscriptionError || paymentsError) throw membersError || subscriptionError || paymentsError;
      return json({ data: { institution, members: members ?? [], subscription: subscription?.[0] ?? null, payments: payments ?? [] } });
    }

    if (path === '/operator/summary' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const [{ count: institutionCount }, { count: incidentCount }, { count: activeCount }, { count: relayCount }, { data: recent }] = await Promise.all([
        supabase.from('institutions').select('id', { count: 'exact', head: true }),
        supabase.from('incidents').select('id', { count: 'exact', head: true }),
        supabase.from('incidents').select('id', { count: 'exact', head: true }).neq('status','resolved').neq('status','closed').neq('status','cancelled'),
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'delivered'),
        supabase.from('incidents').select('id,code,status,category,priority,reported_at').order('reported_at', { ascending: false }).limit(10),
      ]);
      return json({ data: { institutionCount: institutionCount ?? 0, incidentCount: incidentCount ?? 0, activeCount: activeCount ?? 0, relayDelivered: relayCount ?? 0, recent: recent ?? [] } });
    }

    if (path === '/ai/assess' && req.method === 'POST') {
      const body = await req.json();
      const incidentId = requireUuid(textValue(body.incident_id, 64));
      // Authorize the incident BEFORE calling any external AI provider.
      const { data: incidentForAi, error: incidentForAiError } = await supabase.from('incidents').select('id,category,institution_id,reporter_id').eq('id', incidentId).single();
      if (incidentForAiError || !incidentForAi) return json({ error: 'Incident not found' }, 404);
      if (profile.institution_id && incidentForAi.institution_id !== profile.institution_id && !['operator','super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      if (!profile.institution_id && !['operator','super-admin'].includes(profile.role) && incidentForAi.reporter_id !== user.id) return json({ error: 'Not permitted' }, 403);
      const evidence = Array.isArray(body.evidence) ? body.evidence.slice(0, 50) : [];
      const modelResult = await modelAssist({ category: textValue(body.reported_category,30) ?? undefined, description: textValue(body.description,4000) ?? undefined, evidence });
      const result = assessEvidence({
        reportedCategory: textValue(body.reported_category, 30) ?? undefined,
        userConfirmed: typeof body.user_confirmed === 'boolean' ? body.user_confirmed : undefined,
        evidence,
        locationAccuracyM: body.location_accuracy_m == null ? undefined : numberValue(body.location_accuracy_m, 0, 100000) ?? undefined,
        corroboratingReports: Number.isFinite(Number(body.corroborating_reports)) ? Math.max(0, Math.min(5, Number(body.corroborating_reports))) : 0,
        modelAssist: modelResult ? { category: modelResult.category, confidence: modelResult.confidence / 100 } : null,
      });
      const finalResult = modelResult ? { ...result, explanation: `${result.explanation} Model rationale: ${modelResult.rationale}`, model_used: true, model_category: modelResult.category, model_confidence: modelResult.confidence, model_evidence_labels: modelResult.evidence_labels ?? [] } : { ...result, model_used: false };
      const { data, error } = await supabase.rpc('store_ai_assessment_for_incident', {
        p_incident_id: incidentId, p_model_name: finalResult.model_name, p_category: finalResult.category,
        p_confidence: finalResult.confidence, p_fp_code: finalResult.fp_code, p_evidence_ids: [],
        p_explanation: finalResult.explanation, p_decision: finalResult.decision,
        p_metadata: { evidence_strength: finalResult.evidence_strength, margin: finalResult.margin, abstain: finalResult.abstain, reasons: finalResult.reasons, model_used: finalResult.model_used, model_agreement: finalResult.model_agreement, urgency: finalResult.urgency } 
      });
      if (error) throw error;
      return json({ data: { assessment: data, ...finalResult } }, 201);
    }

    if (path === '/ai/assessments' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const { data, error } = await supabase.from('ai_assessments').select('id,incident_id,model_name,category,confidence,fp_code,explanation,decision,created_at').order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      return json({ data: data ?? [] });
    }

    if (path === '/relay/health' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const [{ count: queued }, { count: received }, { count: forwarded }, { count: delivered }, { count: expired }] = await Promise.all([
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'queued'),
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'received'),
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'forwarded'),
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'delivered'),
        supabase.from('relay_packets').select('id', { count: 'exact', head: true }).eq('status', 'expired'),
      ]);
      return json({ data: { queued: queued ?? 0, received: received ?? 0, forwarded: forwarded ?? 0, delivered: delivered ?? 0, expired: expired ?? 0 } });
    }

    if (path === '/system/health' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const started = Date.now();
      const [dbProbe, incidentProbe, relayProbe] = await Promise.all([
        supabase.from('profiles').select('id', { head: true, count: 'exact' }),
        supabase.from('incidents').select('id', { head: true, count: 'exact' }),
        supabase.from('relay_packets').select('id', { head: true, count: 'exact' }),
      ]);
      const checks = [
        { service: 'REACH API', status: 'Healthy', latency_ms: Date.now() - started },
        { service: 'PostgreSQL / Supabase', status: dbProbe.error ? 'Unhealthy' : 'Healthy', error: dbProbe.error?.message ?? null },
        { service: 'Incident store', status: incidentProbe.error ? 'Unhealthy' : 'Healthy', error: incidentProbe.error?.message ?? null },
        { service: 'Relay store', status: relayProbe.error ? 'Unhealthy' : 'Healthy', error: relayProbe.error?.message ?? null },
        { service: 'BMONI configuration', status: bmoniConfigured() ? 'Configured' : 'Not configured' },
        { service: 'AI provider', status: Deno.env.get('REACH_AI_ENDPOINT') && Deno.env.get('REACH_AI_API_KEY') && Deno.env.get('REACH_AI_MODEL') ? 'Configured' : 'Not configured' },
      ];
      return json({ data: checks, checked_at: new Date().toISOString(), overall: checks.some((c) => c.status === 'Unhealthy') ? 'degraded' : 'healthy' });
    }

    if (path === '/notifications' && req.method === 'GET') {
      const { data, error } = await supabase.from('notifications').select('id,incident_id,channel,title,body,status,created_at,sent_at,read_at').order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      return json({ data: data ?? [] });
    }

    if (path === '/audit' && req.method === 'GET') {
      if (!['operator', 'super-admin'].includes(profile.role)) return json({ error: 'Not permitted' }, 403);
      const { data, error } = await supabase.from('audit_logs').select('id,actor_id,institution_id,action,resource_type,resource_id,metadata,created_at').order('created_at', { ascending: false }).limit(100);
      if (error) throw error;
      return json({ data: data ?? [] });
    }

    return json({ error: 'Route not found' }, 404);
  } catch (error) {
    const correlationId = crypto.randomUUID();
    console.error('REACH API request failed', { correlationId, error: error instanceof Error ? error.message : String(error) });
    const message = error instanceof Error ? error.message : 'Request failed';
    const knownClientError = /Authentication|required|Not permitted|denied|not found|already|Invalid|expired|Cannot|must be/i.test(message);
    const providerStatus = Number((error as any)?.status);
    const status = knownClientError ? 403 : (providerStatus >= 400 && providerStatus < 600 ? providerStatus : 500);
    return json({ error: knownClientError ? message : (status >= 500 ? 'Request could not be completed' : message), correlation_id: correlationId }, status);
  }
});
